/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_custom_hid_if.c
  * @version        : v2.0_Cube
  * @brief          : USB Device Custom HID interface file.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usbd_custom_hid_if.h"

/* USER CODE BEGIN INCLUDE */
#include <string.h>

extern volatile int32_t g_hid_target_um;
extern volatile uint8_t g_hid_move_req;
extern volatile uint8_t g_hid_reset_req;
extern volatile int32_t g_hid_jog_um;
extern volatile uint8_t g_hid_jog_req;
/* USER CODE END INCLUDE */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/** @addtogroup STM32_USB_OTG_DEVICE_LIBRARY
  * @brief Usb device.
  * @{
  */

/** @addtogroup USBD_CUSTOM_HID
  * @{
  */

/** @defgroup USBD_CUSTOM_HID_Private_TypesDefinitions USBD_CUSTOM_HID_Private_TypesDefinitions
  * @brief Private types.
  * @{
  */

/* USER CODE BEGIN PRIVATE_TYPES */

/* USER CODE END PRIVATE_TYPES */

/**
  * @}
  */

/** @defgroup USBD_CUSTOM_HID_Private_Defines USBD_CUSTOM_HID_Private_Defines
  * @brief Private defines.
  * @{
  */

/* USER CODE BEGIN PRIVATE_DEFINES */

/* USER CODE END PRIVATE_DEFINES */

/**
  * @}
  */

/** @defgroup USBD_CUSTOM_HID_Private_Macros USBD_CUSTOM_HID_Private_Macros
  * @brief Private macros.
  * @{
  */

/* USER CODE BEGIN PRIVATE_MACRO */

/* USER CODE END PRIVATE_MACRO */

/**
  * @}
  */

/** @defgroup USBD_CUSTOM_HID_Private_Variables USBD_CUSTOM_HID_Private_Variables
  * @brief Private variables.
  * @{
  */

/** Usb HID report descriptor. */
__ALIGN_BEGIN static uint8_t CUSTOM_HID_ReportDesc_FS[USBD_CUSTOM_HID_REPORT_DESC_SIZE] __ALIGN_END =
{
  /* USER CODE BEGIN 0 */
  0x06, 0x00, 0xFF,        /* Usage Page (Vendor Defined 0xFF00)      */
  0x09, 0x01,              /* Usage (0x01)                            */
  0xA1, 0x01,              /* Collection (Application)                */
  0x85, 0x01,              /*   Report ID (1)                         */
  0x09, 0x30,              /*   Usage (0x30): throttle                */
  0x15, 0x00,              /*   Logical Minimum (0)                   */
  0x26, 0xFF, 0x00,        /*   Logical Maximum (255)                 */
  0x75, 0x08,              /*   Report Size (8)                       */
  0x95, 0x01,              /*   Report Count (1)                      */
  0x81, 0x02,              /*   Input (Data,Var,Abs)                  */
  0x09, 0x31,              /*   Usage (0x31): X                       */
  0x16, 0x01, 0x80,        /*   Logical Minimum (-32767)              */
  0x26, 0xFF, 0x7F,        /*   Logical Maximum (32767)               */
  0x75, 0x10,              /*   Report Size (16)                      */
  0x95, 0x01,              /*   Report Count (1)                      */
  0x81, 0x02,              /*   Input (Data,Var,Abs)                  */
  0x09, 0x32,              /*   Usage (0x32): Y                       */
  0x16, 0x01, 0x80,        /*   Logical Minimum (-32767)              */
  0x26, 0xFF, 0x7F,        /*   Logical Maximum (32767)               */
  0x75, 0x10,              /*   Report Size (16)                      */
  0x95, 0x01,              /*   Report Count (1)                      */
  0x81, 0x02,              /*   Input (Data,Var,Abs)                  */
  0x05, 0x09,              /*   Usage Page (Button)                   */
  0x19, 0x01,              /*   Usage Minimum (1)                     */
  0x29, 0x08,              /*   Usage Maximum (8)                     */
  0x15, 0x00,              /*   Logical Minimum (0)                   */
  0x25, 0x01,              /*   Logical Maximum (1)                   */
  0x75, 0x01,              /*   Report Size (1)                       */
  0x95, 0x08,              /*   Report Count (8)                      */
  0x81, 0x02,              /*   Input (Data,Var,Abs)                  */
  0x85, 0xA0,              /*   Report ID (0xA0)                      */
  0x09, 0x02,              /*   Usage (0x02)                          */
  0x15, 0x00,              /*   Logical Minimum (0)                   */
  0x26, 0xFF, 0x00,        /*   Logical Maximum (255)                 */
  0x75, 0x08,              /*   Report Size (8)                       */
  0x95, 0x0F,              /*   Report Count (15)                     */
  0xB1, 0x02,              /*   Feature (Data,Var,Abs)                */
  0x85, 0x02,              /*   Report ID (2)                         */
  0x09, 0x03,              /*   Usage (0x03)                          */
  0x15, 0x00,              /*   Logical Minimum (0)                   */
  0x26, 0xFF, 0x00,        /*   Logical Maximum (255)                 */
  0x75, 0x08,              /*   Report Size (8)                       */
  0x95, 0x06,              /*   Report Count (6): pos[4]+status[2]    */
  0x81, 0x02,              /*   Input (Data,Var,Abs)                  */
  0xC0                     /* End Collection                          */
  /* USER CODE END 0 */
};

/* USER CODE BEGIN PRIVATE_VARIABLES */

/* USER CODE END PRIVATE_VARIABLES */

/**
  * @}
  */

/** @defgroup USBD_CUSTOM_HID_Exported_Variables USBD_CUSTOM_HID_Exported_Variables
  * @brief Public variables.
  * @{
  */
extern USBD_HandleTypeDef hUsbDeviceFS;

/* USER CODE BEGIN EXPORTED_VARIABLES */

/* USER CODE END EXPORTED_VARIABLES */
/**
  * @}
  */

/** @defgroup USBD_CUSTOM_HID_Private_FunctionPrototypes USBD_CUSTOM_HID_Private_FunctionPrototypes
  * @brief Private functions declaration.
  * @{
  */

static int8_t CUSTOM_HID_Init_FS(void);
static int8_t CUSTOM_HID_DeInit_FS(void);
static int8_t CUSTOM_HID_OutEvent_FS(uint8_t event_idx, uint8_t state);
static int8_t CUSTOM_HID_OutReport_FS(uint8_t *report, uint16_t len);

/**
  * @}
  */

USBD_CUSTOM_HID_ItfTypeDef USBD_CustomHID_fops_FS =
{
  CUSTOM_HID_ReportDesc_FS,
  CUSTOM_HID_Init_FS,
  CUSTOM_HID_DeInit_FS,
  CUSTOM_HID_OutEvent_FS,
  CUSTOM_HID_OutReport_FS
};

/** @defgroup USBD_CUSTOM_HID_Private_Functions USBD_CUSTOM_HID_Private_Functions
  * @brief Private functions.
  * @{
  */

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Initializes the CUSTOM HID media low layer
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CUSTOM_HID_Init_FS(void)
{
  /* USER CODE BEGIN 4 */
  return (USBD_OK);
  /* USER CODE END 4 */
}

/**
  * @brief  DeInitializes the CUSTOM HID media low layer
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CUSTOM_HID_DeInit_FS(void)
{
  /* USER CODE BEGIN 5 */
  return (USBD_OK);
  /* USER CODE END 5 */
}

/**
  * @brief  Manage the CUSTOM HID class events
  * @param  event_idx: Event index
  * @param  state: Event state
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CUSTOM_HID_OutEvent_FS(uint8_t event_idx, uint8_t state)
{
  /* USER CODE BEGIN 6 */
  return (USBD_OK);
  /* USER CODE END 6 */
}

/**
  * @brief  0xA0 feature report: [0x13][int32 distance in 0.001 mm]
  */
static int8_t CUSTOM_HID_OutReport_FS(uint8_t *report, uint16_t len)
{
  uint8_t  *p = report;
  uint16_t  n = len;

  /* Some hosts include the report ID in the data stage. */
  if ((n >= 2U) && (p[0] == 0xA0U))
  {
    p++;
    n--;
  }

  if ((n >= 1U) && (p[0] == 0x14U))
  {
    g_hid_reset_req = 1U;
    return (USBD_OK);
  }

  if ((n >= 5U) && (p[0] == 0x15U))
  {
    int32_t um;

    memcpy(&um, &p[1], sizeof(um));
    g_hid_jog_um = um;
    g_hid_jog_req = 1U;
    return (USBD_OK);
  }

  if ((n >= 5U) && (p[0] == 0x13U))
  {
    int32_t um;

    memcpy(&um, &p[1], sizeof(um));
    g_hid_target_um = um;
    g_hid_move_req = 1U;
  }

  return (USBD_OK);
}

/* USER CODE BEGIN 7 */
/**
  * @brief  Send the report to the Host
  * @param  report: The report to be sent
  * @param  len: The report length
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
/*
static int8_t USBD_CUSTOM_HID_SendReport_FS(uint8_t *report, uint16_t len)
{
  return USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, report, len);
}
*/
/* USER CODE END 7 */

/* USER CODE BEGIN PRIVATE_FUNCTIONS_IMPLEMENTATION */

/* USER CODE END PRIVATE_FUNCTIONS_IMPLEMENTATION */
/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

